from Live import load_game, welcome

print(welcome(input('Hello before we start can you please tell me your name?')))
load_game()
